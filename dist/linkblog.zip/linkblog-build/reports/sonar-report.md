### MAJOR — CODE_SMELL

- **File:** linkblog.php
- **Line:** 400
- **Rule:** php:S1142
- **Message:** This function has 5 returns, which is more than the 3 allowed.
- **Effort:** 20min

### CRITICAL — CODE_SMELL

- **File:** linkblog.php
- **Line:** 400
- **Rule:** php:S3776
- **Message:** Refactor this function to reduce its Cognitive Complexity from 60 to the 15 allowed.
- **Effort:** 50min

### MINOR — CODE_SMELL

- **File:** linkblog.php
- **Line:** 400
- **Rule:** php:S100
- **Message:** Rename function "linkblog_create_roundup_post" to match the regular expression ^[a-z][a-zA-Z0-9]\*$.
- **Effort:** 5min

### MINOR — CODE_SMELL

- **File:** linkblog.php
- **Line:** 574
- **Rule:** php:S100
- **Message:** Rename function "linkblog_get_publish_statistics" to match the regular expression ^[a-z][a-zA-Z0-9]\*$.
- **Effort:** 5min

### MINOR — CODE_SMELL

- **File:** linkblog.php
- **Line:** 622
- **Rule:** php:S100
- **Message:** Rename function "linkblog_get_links_grouped_by_category" to match the regular expression ^[a-z][a-zA-Z0-9]\*$.
- **Effort:** 5min

### CRITICAL — CODE_SMELL

- **File:** linkblog.php
- **Line:** 663
- **Rule:** php:S1192
- **Message:** Define a constant instead of duplicating this literal "NOT EXISTS" 5 times.
- **Effort:** 12min

### MINOR — CODE_SMELL

- **File:** linkblog.php
- **Line:** 681
- **Rule:** php:S100
- **Message:** Rename function "linkblog_unpublish_link" to match the regular expression ^[a-z][a-zA-Z0-9]\*$.
- **Effort:** 5min

### MINOR — CODE_SMELL

- **File:** linkblog.php
- **Line:** 716
- **Rule:** php:S100
- **Message:** Rename function "linkblog_admin_menu" to match the regular expression ^[a-z][a-zA-Z0-9]\*$.
- **Effort:** 5min

### MINOR — CODE_SMELL

- **File:** linkblog.php
- **Line:** 819
- **Rule:** php:S100
- **Message:** Rename function "linkblog_settings_page" to match the regular expression ^[a-z][a-zA-Z0-9]\*$.
- **Effort:** 5min

### MAJOR — CODE_SMELL

- **File:** linkblog.php
- **Line:** 838
- **Rule:** Web:S6853
- **Message:** A form label must be associated with a control and have accessible text.
- **Effort:** 5min

### MAJOR — CODE_SMELL

- **File:** linkblog.php
- **Line:** 864
- **Rule:** Web:S6853
- **Message:** A form label must be associated with a control and have accessible text.
- **Effort:** 5min

### MINOR — CODE_SMELL

- **File:** linkblog.php
- **Line:** 944
- **Rule:** php:S100
- **Message:** Rename function "linkblog_schedule_page" to match the regular expression ^[a-z][a-zA-Z0-9]\*$.
- **Effort:** 5min

### MINOR — CODE_SMELL

- **File:** linkblog.php
- **Line:** 956
- **Rule:** php:S100
- **Message:** Rename function "linkblog_enqueue_admin_assets" to match the regular expression ^[a-z][a-zA-Z0-9]\*$.
- **Effort:** 5min

### MINOR — BUG

- **File:** linkblog.php
- **Line:** 972
- **Rule:** php:S2003
- **Message:** Replace "require" with "require_once".
- **Effort:** 5min

### CRITICAL — CODE_SMELL

- **File:** linkblog.php
- **Line:** 972
- **Rule:** php:S6600
- **Message:** Remove the parentheses from this "require" call.
- **Effort:** 2min

### MINOR — CODE_SMELL

- **File:** linkblog.php
- **Line:** 998
- **Rule:** php:S100
- **Message:** Rename function "linkblog_add_dashboard_widget" to match the regular expression ^[a-z][a-zA-Z0-9]\*$.
- **Effort:** 5min

### MINOR — CODE_SMELL

- **File:** linkblog.php
- **Line:** 1010
- **Rule:** php:S100
- **Message:** Rename function "linkblog_register_rest_routes" to match the regular expression ^[a-z][a-zA-Z0-9]\*$.
- **Effort:** 5min

### CRITICAL — CODE_SMELL

- **File:** linkblog.php
- **Line:** 1011
- **Rule:** php:S1192
- **Message:** Define a constant instead of duplicating this literal "linkblog/v1" 4 times.
- **Effort:** 10min

### MINOR — CODE_SMELL

- **File:** linkblog.php
- **Line:** 1069
- **Rule:** php:S100
- **Message:** Rename function "linkblog_rest_delete_link" to match the regular expression ^[a-z][a-zA-Z0-9]\*$.
- **Effort:** 5min

### MINOR — CODE_SMELL

- **File:** linkblog.php
- **Line:** 1081
- **Rule:** php:S100
- **Message:** Rename function "linkblog_get_schedule" to match the regular expression ^[a-z][a-zA-Z0-9]\*$.
- **Effort:** 5min

### MINOR — CODE_SMELL

- **File:** linkblog.php
- **Line:** 1097
- **Rule:** php:S100
- **Message:** Rename function "linkblog_save_schedule" to match the regular expression ^[a-z][a-zA-Z0-9]\*$.
- **Effort:** 5min

### MINOR — CODE_SMELL

- **File:** linkblog.php
- **Line:** 1109
- **Rule:** php:S100
- **Message:** Rename function "linkblog_rest_permission_check" to match the regular expression ^[a-z][a-zA-Z0-9]\*$.
- **Effort:** 5min

### MINOR — CODE_SMELL

- **File:** linkblog.php
- **Line:** 1125
- **Rule:** php:S100
- **Message:** Rename function "linkblog_rest_add_link" to match the regular expression ^[a-z][a-zA-Z0-9]\*$.
- **Effort:** 5min

### CRITICAL — CODE_SMELL

- **File:** linkblog.php
- **Line:** 1125
- **Rule:** php:S3776
- **Message:** Refactor this function to reduce its Cognitive Complexity from 18 to the 15 allowed.
- **Effort:** 8min

### MINOR — CODE_SMELL

- **File:** linkblog.php
- **Line:** 1190
- **Rule:** php:S100
- **Message:** Rename function "linkblog_rest_get_categories" to match the regular expression ^[a-z][a-zA-Z0-9]\*$.
- **Effort:** 5min

### MAJOR — CODE_SMELL

- **File:** linkblog.php
- **Line:** 1190
- **Rule:** php:S1172
- **Message:** Remove the unused function parameter "$request".
- **Effort:** 5min

### MINOR — CODE_SMELL

- **File:** linkblog.php
- **Line:** 1220
- **Rule:** php:S100
- **Message:** Rename function "linkblog_invalidate_categories_cache" to match the regular expression ^[a-z][a-zA-Z0-9]\*$.
- **Effort:** 5min

### MINOR — CODE_SMELL

- **File:** linkblog.php
- **Line:** 1230
- **Rule:** php:S100
- **Message:** Rename function "linkblog_add_cors_headers" to match the regular expression ^[a-z][a-zA-Z0-9]\*$.
- **Effort:** 5min

### MINOR — CODE_SMELL

- **File:** linkblog.php
- **Line:** 1247
- **Rule:** php:S100
- **Message:** Rename function "linkblog_handle_preflight" to match the regular expression ^[a-z][a-zA-Z0-9]\*$.
- **Effort:** 5min

### MINOR — CODE_SMELL

- **File:** linkblog.php
- **Line:** 1265
- **Rule:** php:S100
- **Message:** Rename function "linkblog_dashboard_widget_content" to match the regular expression ^[a-z][a-zA-Z0-9]\*$.
- **Effort:** 5min

### CRITICAL — CODE_SMELL

- **File:** linkblog.php
- **Line:** 1284
- **Rule:** php:S1192
- **Message:** Define a constant instead of duplicating this literal "NOT IN" 4 times.
- **Effort:** 10min

### MINOR — CODE_SMELL

- **File:** linkblog.php
- **Line:** 1338
- **Rule:** php:S100
- **Message:** Rename function "linkblog_dashboard_page" to match the regular expression ^[a-z][a-zA-Z0-9]\*$.
- **Effort:** 5min

### MAJOR — CODE_SMELL

- **File:** linkblog.php
- **Line:** 1338
- **Rule:** php:S138
- **Message:** This function "linkblog_dashboard_page" has 224 lines, which is greater than the 150 lines authorized. Split it into smaller functions.
- **Effort:** 20min

### MINOR — CODE_SMELL

- **File:** linkblog.php
- **Line:** 1437
- **Rule:** php:S1481
- **Message:** Remove this unused "$total_tags" local variable.
- **Effort:** 5min

### MAJOR — CODE_SMELL

- **File:** linkblog.php
- **Line:** 1591
- **Rule:** php:S1854
- **Message:** Remove this useless assignment to local variable '$url'.
- **Effort:** 1min

### MINOR — CODE_SMELL

- **File:** linkblog.php
- **Line:** 1763
- **Rule:** php:S100
- **Message:** Rename function "linkblog_show_links_page" to match the regular expression ^[a-z][a-zA-Z0-9]\*$.
- **Effort:** 5min

### CRITICAL — CODE_SMELL

- **File:** linkblog.php
- **Line:** 1763
- **Rule:** php:S3776
- **Message:** Refactor this function to reduce its Cognitive Complexity from 71 to the 15 allowed.
- **Effort:** 1h1min

### MAJOR — CODE_SMELL

- **File:** linkblog.php
- **Line:** 1769
- **Rule:** php:S1066
- **Message:** Merge this if statement with the enclosing one.
- **Effort:** 5min

### MAJOR — CODE_SMELL

- **File:** linkblog.php
- **Line:** 1781
- **Rule:** php:S1066
- **Message:** Merge this if statement with the enclosing one.
- **Effort:** 5min

### MAJOR — CODE_SMELL

- **File:** linkblog.php
- **Line:** 1793
- **Rule:** php:S1066
- **Message:** Merge this if statement with the enclosing one.
- **Effort:** 5min

### MAJOR — CODE_SMELL

- **File:** linkblog.php
- **Line:** 1805
- **Rule:** php:S1066
- **Message:** Merge this if statement with the enclosing one.
- **Effort:** 5min

### MINOR — CODE_SMELL

- **File:** linkblog.php
- **Line:** 1918
- **Rule:** php:S100
- **Message:** Rename function "linkblog_add_link_page" to match the regular expression ^[a-z][a-zA-Z0-9]\*$.
- **Effort:** 5min

### CRITICAL — CODE_SMELL

- **File:** linkblog.php
- **Line:** 1918
- **Rule:** php:S3776
- **Message:** Refactor this function to reduce its Cognitive Complexity from 37 to the 15 allowed.
- **Effort:** 27min

### CRITICAL — BUG

- **File:** linkblog.php
- **Line:** 2009
- **Rule:** Web:S7930
- **Message:** Duplicate id "linkblog_url" found. First occurrence was on line 183.
- **Effort:** 5min

### MINOR — CODE_SMELL

- **File:** src/schedule/App.jsx
- **Line:** 12
- **Rule:** javascript:S7776
- **Message:** `SCHEDULE_MODES` should be a `Set`, and use `SCHEDULE_MODES.has()` to check existence or non-existence.
- **Effort:** 5min

### MAJOR — CODE_SMELL

- **File:** src/schedule/App.jsx
- **Line:** 61
- **Rule:** javascript:S3358
- **Message:** Extract this nested ternary operation into an independent statement.
- **Effort:** 5min

### MAJOR — CODE_SMELL

- **File:** src/schedule/App.jsx
- **Line:** 90
- **Rule:** javascript:S3358
- **Message:** Extract this nested ternary operation into an independent statement.
- **Effort:** 5min

### MINOR — CODE_SMELL

- **File:** src/schedule/components/NextSchedules.jsx
- **Line:** 5
- **Rule:** javascript:S7776
- **Message:** `SCHEDULE_MODES` should be a `Set`, and use `SCHEDULE_MODES.has()` to check existence or non-existence.
- **Effort:** 5min

### MAJOR — CODE_SMELL

- **File:** src/schedule/components/NextSchedules.jsx
- **Line:** 38
- **Rule:** javascript:S6479
- **Message:** Do not use Array index in keys
- **Effort:** 5min

### MINOR — CODE_SMELL

- **File:** src/schedule/components/RecurrenceConfig.jsx
- **Line:** 38
- **Rule:** javascript:S7773
- **Message:** Prefer `Number.parseInt` over `parseInt`.
- **Effort:** 2min

### MINOR — CODE_SMELL

- **File:** src/schedule/components/RecurrenceConfig.jsx
- **Line:** 41
- **Rule:** javascript:S7735
- **Message:** Unexpected negated condition.
- **Effort:** 2min

### MINOR — CODE_SMELL

- **File:** src/schedule/components/RecurrenceConfig.jsx
- **Line:** 54
- **Rule:** javascript:S7773
- **Message:** Prefer `Number.parseInt` over `parseInt`.
- **Effort:** 2min

### MINOR — CODE_SMELL

- **File:** src/schedule/components/RecurrenceConfig.jsx
- **Line:** 57
- **Rule:** javascript:S7735
- **Message:** Unexpected negated condition.
- **Effort:** 2min

### MINOR — CODE_SMELL

- **File:** src/schedule/components/RecurrenceConfig.jsx
- **Line:** 99
- **Rule:** javascript:S7773
- **Message:** Prefer `Number.parseInt` over `parseInt`.
- **Effort:** 2min

### MINOR — CODE_SMELL

- **File:** src/schedule/components/RecurrenceConfig.jsx
- **Line:** 102
- **Rule:** javascript:S7735
- **Message:** Unexpected negated condition.
- **Effort:** 2min

### MAJOR — CODE_SMELL

- **File:** src/schedule/components/RecurrenceConfig.jsx
- **Line:** 110
- **Rule:** javascript:S6848
- **Message:** Avoid non-native interactive elements. If using native HTML is not possible, add an appropriate role and support for tabbing, mouse, keyboard, and touch inputs to an interactive content element.
- **Effort:** 5min

### MINOR — BUG

- **File:** src/schedule/components/RecurrenceConfig.jsx
- **Line:** 110
- **Rule:** javascript:S1082
- **Message:** Visible, non-interactive elements with click handlers must have at least one keyboard listener.
- **Effort:** 5min

### MINOR — CODE_SMELL

- **File:** src/schedule/components/RecurrenceConfig.jsx
- **Line:** 118
- **Rule:** javascript:S7773
- **Message:** Prefer `Number.parseInt` over `parseInt`.
- **Effort:** 2min

### MAJOR — CODE_SMELL

- **File:** src/schedule/components/RecurrenceConfig.jsx
- **Line:** 125
- **Rule:** javascript:S6848
- **Message:** Avoid non-native interactive elements. If using native HTML is not possible, add an appropriate role and support for tabbing, mouse, keyboard, and touch inputs to an interactive content element.
- **Effort:** 5min

### MINOR — BUG

- **File:** src/schedule/components/RecurrenceConfig.jsx
- **Line:** 125
- **Rule:** javascript:S1082
- **Message:** Visible, non-interactive elements with click handlers must have at least one keyboard listener.
- **Effort:** 5min

### MINOR — CODE_SMELL

- **File:** src/schedule/components/RecurrenceConfig.jsx
- **Line:** 132
- **Rule:** javascript:S7773
- **Message:** Prefer `Number.parseInt` over `parseInt`.
- **Effort:** 2min

### MINOR — CODE_SMELL

- **File:** src/schedule/components/TriggerCondition.jsx
- **Line:** 12
- **Rule:** javascript:S7773
- **Message:** Prefer `Number.parseInt` over `parseInt`.
- **Effort:** 2min

### MINOR — CODE_SMELL

- **File:** src/schedule/components/TriggerCondition.jsx
- **Line:** 15
- **Rule:** javascript:S7735
- **Message:** Unexpected negated condition.
- **Effort:** 2min

### MINOR — CODE_SMELL

- **File:** src/schedule/components/TriggerCondition.jsx
- **Line:** 27
- **Rule:** javascript:S7773
- **Message:** Prefer `Number.parseInt` over `parseInt`.
- **Effort:** 2min

### MINOR — CODE_SMELL

- **File:** src/schedule/components/TriggerCondition.jsx
- **Line:** 30
- **Rule:** javascript:S7735
- **Message:** Unexpected negated condition.
- **Effort:** 2min

### MAJOR — CODE_SMELL

- **File:** src/schedule/lib/rrule.js
- **Line:** 10
- **Rule:** javascript:S4624
- **Message:** Refactor this code to not use nested template literals.
- **Effort:** 10min

### MINOR — CODE_SMELL

- **File:** src/schedule/lib/rrule.js
- **Line:** 25
- **Rule:** javascript:S1481
- **Message:** Remove the declaration of the unused 'NTH' variable.
- **Effort:** 5min

### MAJOR — CODE_SMELL

- **File:** src/schedule/lib/rrule.js
- **Line:** 25
- **Rule:** javascript:S1854
- **Message:** Remove this useless assignment to variable "NTH".
- **Effort:** 1min

### MAJOR — CODE_SMELL

- **File:** src/schedule/lib/rrule.js
- **Line:** 37
- **Rule:** javascript:S3358
- **Message:** Extract this nested ternary operation into an independent statement.
- **Effort:** 5min
